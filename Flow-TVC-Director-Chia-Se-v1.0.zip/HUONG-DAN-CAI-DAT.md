# Cài đặt Flow TVC Director

## Gói này làm được gì

- Tự mở Google Flow trong trình duyệt của Codex.
- Ghi nhớ project, avatar, nhân vật và khóa trang phục riêng của từng người dùng.
- Tạo TVC Omni dọc 9:16, 10 giây, chất lượng cao nhất, x1.
- Viết 2–3 góc quay điện ảnh, ưu tiên cận cảnh, thần thái và giao tiếp ánh mắt.
- Giữ hành động liên tục tới khung hình cuối, không đứng hình sớm.
- Không tạo lời thoại hoặc voice-over.
- Phát và kiểm tra video ở đầu, giữa, cuối; tự sửa prompt tối đa một lần nếu có lỗi rõ.

## Cách cài

1. Giải nén gói ZIP.
2. Sao chép cả thư mục `flow-tvc-director` vào thư mục skill cá nhân của Codex: `%USERPROFILE%\\.codex\\skills\\`.
3. Mở một đoạn chat Codex mới.
4. Gọi: `$flow-tvc-director thiết lập lần đầu cho tôi`.
5. Đăng nhập Google Flow bằng tay nếu được yêu cầu, chọn hoặc tạo project, rồi cung cấp tên hiển thị của avatar và nhân vật.

## Cách gọi sau khi thiết lập

`$flow-tvc-director tạo TVC [ý tưởng của bạn]`

Ví dụ:

`$flow-tvc-director tạo TVC tôi bế nhân vật chính trên thảo nguyên lúc hoàng hôn, ba góc quay cận điện ảnh.`

## Dữ liệu không có trong gói

Gói không chứa tài khoản Google, cookie, mật khẩu, OTP, API key, credit, ảnh khuôn mặt, avatar, nhân vật, sản phẩm, bối cảnh hoặc quyền truy cập project của người tạo gói. Mỗi người nhận phải đăng nhập Flow và cấu hình tài sản của chính họ.

## Lưu ý

- Người nhận cần Codex có khả năng điều khiển trình duyệt trong ứng dụng.
- Người nhận cần có quyền sử dụng Google Flow và đủ credit để tạo video.
- Tùy chọn/model của Flow có thể thay đổi; skill sẽ ưu tiên chất lượng cao nhất đang khả dụng.

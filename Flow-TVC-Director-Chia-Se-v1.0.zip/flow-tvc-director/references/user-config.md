# Cấu hình cá nhân — điền trong lần sử dụng đầu tiên

- `project_name`:
- `project_url`:
- `avatar_alias`:
- `avatar_flow_name`:
- `character_alias`:
- `character_flow_name`:
- `avatar_wardrobe_lock`:
- `preferred_model`: Omni 1.1 Flash
- `aspect_ratio`: 9:16
- `quality`: highest available
- `duration`: 10 seconds
- `outputs`: x1
- `audio_rule`: no dialogue, no speech, no voice-over

Chỉ lưu các cấu hình vận hành đã được người dùng xác nhận. Không lưu mật khẩu, cookie, OTP, API key, thông tin thanh toán hoặc bí mật đăng nhập.

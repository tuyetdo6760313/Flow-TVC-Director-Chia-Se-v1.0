# Nhân vật và avatar của người dùng

Tệp này là sổ alias mẫu. Dữ liệu thật phải được lấy từ `user-config.md` sau onboarding.

## Cách ghi alias

| Cách người dùng gọi | Tên hiển thị chính xác trong Flow | Loại | Cách chọn |
| --- | --- | --- | --- |
| tôi, avatar tôi | Điền sau onboarding | Hình đại diện | Mở bộ chọn thành phần → `Hình đại diện` → chọn đúng tên đã lưu |
| nhân vật chính | Điền sau onboarding | Nhân vật | Mở bộ chọn thành phần → `Nhân vật` → chọn đúng tên đã lưu |

## Quy tắc

- Không lưu ảnh khuôn mặt, cookie, mật khẩu, OTP hoặc khóa API trong skill.
- Luôn chọn entity thật trong Flow; không mô tả lại khuôn mặt bằng chữ để thay cho tài sản.
- Khi người dùng đổi project hoặc đổi tên tài sản, cập nhật `user-config.md` sau khi họ xác nhận.
- Nếu bối cảnh đã chứa sẵn một nhân vật, không gắn thêm entity trùng gây nhân bản.

# Bản đồ giao diện Google Flow

Quan sát trực tiếp ngày 2026-09-07. Tên và tùy chọn có thể đổi; luôn đọc lại giao diện hiện tại trước khi thao tác.

## Điều hướng dự án

- `Tất cả nội dung nghe nhìn`: xem toàn bộ tài sản và kết quả.
- `Hình ảnh`: lọc ảnh.
- `Video`: lọc video.
- `Nhân vật`: quản lý/chọn nhân vật đã tạo.
- `Cảnh`: xem cảnh.
- `Tệp tải lên`: xem tài sản người dùng đã tải.
- `Công cụ`: mở trang công cụ của project.
- `Thùng rác`: không thao tác nếu người dùng không yêu cầu.

Thanh trên có tìm kiếm, lọc/sắp xếp, thêm media, trợ giúp, cài đặt lưới và menu dự án.

## Ô tạo và thư viện

- Ô prompt: `Bạn muốn tạo những gì?`.
- `Thêm thành phần vào ô nhập câu lệnh`: mở thư viện tài sản.
- Các tab: `Tất cả`, `Hình ảnh`, `Video`, `Giọng nói`, `Nhân vật`, `Hình đại diện`, `Tệp tải lên`.
- Có tìm kiếm, sắp xếp `Gần đây`, `Tải nội dung nghe nhìn lên` và `Thêm vào câu lệnh`.
- `Bắt đầu tạo`: gửi tác vụ khi prompt/tài sản hợp lệ.

## Cài đặt tạo

- Chế độ: `Hình ảnh`, `Video`.
- Loại video: `Khung hình`, `Thành phần`.
- Tỷ lệ: `16:9`, `9:16`.
- Model quan sát được: `Omni 1.1 Flash`, `Veo 3.1 - Lite`, `Veo 3.1 - Fast`, `Veo 3.1 - Quality`.
- Độ phân giải video: `360p`, `720p`.
- Thời lượng: `4 giây`, `6 giây`, `8 giây`, `10 giây`.
- Số lượng đầu ra: `x1`, `x2`, `x3`, `x4`.
- Omni 1.1 Flash 720p 10 giây x1 hiển thị 15 credit tại thời điểm quan sát; đọc lại con số hiện tại trước khi báo chi phí.

## Quy tắc thao tác an toàn

- Ưu tiên locator theo vai trò và tên hiển thị; chỉ dùng tọa độ sau khi ảnh chụp xác nhận vị trí.
- Sau mỗi lựa chọn, kiểm tra trạng thái radio/button hoặc nhãn tóm tắt.
- Không tải lại trang khi có prompt/tài sản chưa gửi.
- Không xóa tài sản, đổi tên project, chia sẻ hay thay quyền truy cập nếu chưa được yêu cầu rõ.
- Trước khi upload ảnh cá nhân mới, xác nhận đúng tệp và đúng project.
